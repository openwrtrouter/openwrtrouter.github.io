//go:build !darwin
// +build !darwin

package cmd

// SigInfoHandler creates SigInfo handler
func SigInfoHandler() {
}
